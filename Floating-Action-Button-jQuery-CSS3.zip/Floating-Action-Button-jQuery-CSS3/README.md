# tiny-fab
a tiny folating action button plugin based on jQuery
